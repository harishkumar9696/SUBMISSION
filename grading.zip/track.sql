--Grading set  <28/11/2017>
--submitted by <h.f.chandrasekaran>


/* Provide a query that includes the purchased track name AND artist name with each invoice line item. */
select t.name as track ,a.name as artist from track t,album al, artist a,invoiceline i 
where t.albumid=al.albumid 
and al.artistid=a.artistid 
and t.trackid=i.trackid;