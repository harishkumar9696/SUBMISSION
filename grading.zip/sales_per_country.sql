--Grading set  <28/11/2017>
--submitted by <h.f.chandrasekaran>

 /* Provide a query that shows the total sales per country. */
select sum(total),billingcountry from invoice
 group by billingcountry;
