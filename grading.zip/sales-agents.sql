--Grading set  <28/11/2017>
--submitted by <h.f.chandrasekaran>
 

/* Provide a query showing only the Employees who are Sales Agents. */
select firstname from employee where title like '%sales%Agent';