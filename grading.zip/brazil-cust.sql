--Grading set  <28/11/2017>
--submitted by <h.f.chandrasekaran>


/* Provide a query only showing the Customers from Brazil. */

select * from customer where country='Brazil';