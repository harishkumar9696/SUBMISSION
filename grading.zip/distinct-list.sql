--Grading set  <28/11/2017>
--submitted by <h.f.chandrasekaran>


/* Provide a query showing a unique/distinct list of billing countries from the Invoice table. */
select distinct billingcountry from invoice;